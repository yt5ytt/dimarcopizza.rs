<?php
$db_users = new mysqli("localhost", "dimarcop_users", "sna2405976", "dimarcop_dimarko");
$db_admin = new mysqli ("localhost", "dimarcop_admin", "sna2405976", "dimarcop_dimarko");
?>