<?php 
	header("Location: http://www.dimarcopizza.rs");
?>